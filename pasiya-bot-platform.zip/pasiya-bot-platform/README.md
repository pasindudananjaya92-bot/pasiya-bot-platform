# Pasiya Bot Platform

**Completely Free AI Bot Builder & Control Center**

Create, test and prepare powerful AI bots using only free services. No credit card required.

## What this platform gives you

- Live Bot Builder (chat with your bot instantly)
- Free LLM providers (Groq, Google AI Studio, OpenRouter...)
- Free hosting platforms for 24/7 bots
- Free tools for memory, database, automation
- Complete step-by-step guide to build real bots
- Everything runs after uploading to GitHub Pages

## How to go live in 2 minutes

1. Create a new GitHub repository
2. Upload `index.html`
3. Go to **Settings → Pages**
4. Select branch `main` and folder `/ (root)`
5. Save → Your site is live

## Recommended Free Stack

| Purpose       | Free Service              |
|---------------|---------------------------|
| Brain (LLM)   | Groq or Google AI Studio  |
| Chat Interface| Telegram Bot (free)       |
| Hosting       | Replit / Railway          |
| Memory        | Supabase or Upstash       |
| Automation    | n8n or Make free plan     |
| Keep Alive    | cron-job.org              |

## How to use the Bot Builder

1. Go to [console.groq.com](https://console.groq.com) and create a free API key
2. Paste the key in the Bot Builder
3. Write a system prompt
4. Start chatting

Your API key is stored only in your browser (localStorage). It never leaves your device except when calling the free API.

## Author

**Pasindu Dananjaya**

- GitHub: https://github.com/pasindudananjaya92-bot
- Blog: https://pasindudananjaya.substack.com

---

100% Free Services Only • Built for creators who want powerful bots without paying
